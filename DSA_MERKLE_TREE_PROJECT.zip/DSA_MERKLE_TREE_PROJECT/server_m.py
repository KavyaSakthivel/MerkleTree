import socket
from Crypto.Cipher import AES


## BY:   SUBHASHINI  (CB.EN.U4AIE22061)
##       KAVYA       (CB.EN.U4AIE22065)

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
host = "localhost"
port = 9999
server.bind((host,port))
server.listen(1)
client, addr = server.accept()

print("Server listening on port 9999")
print("\n")

file_data= client.recv(1024)





    # Write decrypted data to a new file
with open("received_file_from_client.txt", "wb") as f:
    f.write(file_data)

print("Data from client stored in received_file_from_client.txt ")
print("The data is: ", file_data)
print("\n")


# Receive client's request
request = client.recv(1024)
# Check if the client is requesting the data
if request == b"Request":
    
    print("Client requested the data.")
    with open('received_file_from_client.txt', 'rb') as file:
        file_datas = file.read()

        # Send the content of the 'ReceivedFile.txt' to the client
    client.send(file_datas)
    print("Sent 'received_file_from_client.txt' data ")
    print("\n")


client.close()



