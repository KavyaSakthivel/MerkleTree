import os
import socket
from Crypto.Cipher import AES
import hashlib


## BY:   SUBHASHINI  (CB.EN.U4AIE22061)
##       KAVYA       (CB.EN.U4AIE22065)

# merkle tree part 
def hash(val) -> str:
    if isinstance(val, str):
        val = val.encode('utf-8')
    return hashlib.sha256(val).hexdigest()


def build_tree_rec(nodes) -> dict:
    half = len(nodes) // 2

    if len(nodes) == 2:
        return {"left": nodes[0], "right": nodes[1], "value": hash(nodes[0]["value"] + nodes[1]["value"])}

    left = build_tree_rec(nodes[:half])
    right = build_tree_rec(nodes[half:])
    value = hash(left["value"] + right["value"])

    return {"left": left, "right": right, "value": value}

def build_tree(values) -> dict:
    leaves = [{"left": None, "right": None, "value": hash(e)} for e in values]
    if len(leaves) % 2 == 1:
        leaves.append(leaves[-1])  # duplicate last element if odd number of elements
    root = build_tree_rec(leaves)
    return root

def get_root_hash(root) -> str:
    return root["value"]




#DRIVER CODE

key = b"SubhashiniKavyaK"  # must be 16 bytes
nonce = b"SubhashiniKavyaN"
cipher = AES.new(key, AES.MODE_EAX, nonce)

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(("localhost", 9999))

file_path = "dsaprjct.txt"

with open(file_path, "rb") as f:
    data = f.read()

print('\n')

print(" Data is: ",data)
encrypted = cipher.encrypt(data)
print("\n")
print("Data has been encrypted: ")
print(encrypted)
print("\n")

merkle_tree = build_tree([hash(data)])
ini_merkle_root = get_root_hash(merkle_tree)


print("Intital Merkle Root:", ini_merkle_root)
print("\n")

client.send(encrypted)
print("\n")
print("Encrypted data sent")

print("\n")


decipher = AES.new(key, AES.MODE_EAX, nonce)




client.send("Request".encode())

print("Requested from the server")

# Receive the data from the server
received_data = client.recv(1024)


# Save the received data to a file
with open('EncryptedFile_From_Server.txt', 'wb') as file:
    file.write(received_data)

print("Saved received encrypted data to 'EncryptedFile_From_Server.txt'")
print("\n")
print("Encrypted Data is: ",received_data)
print("\n")
    # Decrypt the received data
decrypted_data = decipher.decrypt(received_data)
print("Data has been decrypted in order to find the merkle root value")
print("Decrypted Data is: ",decrypted_data)

    


with open('DecryptedFile.txt', 'wb') as file:
    file.write(decrypted_data)
    
print("The decrypted data has been wriiten to 'DecryptedFile.txt")

# Generate a new Merkle tree from the decrypted data
new_merkle_tree =build_tree([hash(decrypted_data)])
new_merkle_root = get_root_hash(new_merkle_tree)

print("\n")
print("Merkel Root for the received data is: ")

print(new_merkle_root)
print("\n")  

if new_merkle_root == ini_merkle_root:
    print("No data intergretity is lost")
else:
    print("Data intergrity is lost")




client.close()